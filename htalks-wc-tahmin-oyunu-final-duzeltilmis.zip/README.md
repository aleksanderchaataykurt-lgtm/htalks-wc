# H-Talks Puanlamalı WC Tahmin Oyunu

Bu sürümde maçlar direkt `index.html` içine yazılıdır. Bu yüzden JS, API veya Supabase çalışmasa bile maç listesi görünür.

## Admin

- Kullanıcı adı: `admin`
- Şifre: `aleks02`

## Supabase

Supabase tarafında yalnızca `supabase_schema.sql` dosyasını SQL Editor içine yapıştırıp `Run` demen yeterli.

Tablolar:

- `maclar`
- `kuponlar`
- `liderlik_tablosu`

## Vercel Environment Variables

Vercel > Project > Settings > Environment Variables içine bunları ekle:

```txt
SUPABASE_URL=https://aleksanderchaataykurt-lgtm.supabase.co
SUPABASE_SERVICE_ROLE_KEY=sb_secret_...
ADMIN_USER=admin
ADMIN_PASSWORD=aleks02
```

`SUPABASE_URL` çalışmazsa Supabase > Settings > Data API kısmındaki Project URL değerini kopyala.

`SUPABASE_SERVICE_ROLE_KEY` yerine Supabase > Settings > API Keys kısmındaki `sb_secret_...` ile başlayan Secret key yazılacak.

## Önemli

Bu sürümde `src/app.js` içine Supabase key yazılmıyor. Frontend sadece `/api/...` endpointlerini çağırıyor. Supabase gizli bağlantısı Vercel backend tarafında çalışıyor.

## Deploy

1. Dosyaları GitHub reposuna yükle.
2. Vercel'den repo seçip deploy et.
3. Environment Variables değerlerini gir.
4. Vercel > Deployments > Redeploy yap.

## Kullanım

- Kullanıcı 24 maçın tamamını seçer.
- Kupon kilitlenir.
- Aynı IP veya aynı tarayıcıdan ikinci kupon reddedilir.
- Admin panelden sonuçlar elle girilir.
- Kaydedince tüm puanlar ve liderlik tablosu güncellenir.
