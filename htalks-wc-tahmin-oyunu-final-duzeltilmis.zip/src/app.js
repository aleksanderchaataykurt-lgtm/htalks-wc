const TOPLAM_MAC = 24;
const KILIT_ANAHTARI = 'htalks_kupon_kilit_v6';
const KUPON_ANAHTARI = 'htalks_kupon_no_v6';

const sec = (id) => document.getElementById(id);

function temizle(deger) {
  return String(deger ?? '')
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function mesajYaz(id, metin, tip = '') {
  const alan = sec(id);
  if (!alan) return;
  alan.className = `mesaj ${tip}`.trim();
  alan.textContent = metin;
}

function tarayiciKimligiAl() {
  let kimlik = localStorage.getItem(KILIT_ANAHTARI);
  if (!kimlik) {
    kimlik = 'BR-' + Math.random().toString(36).slice(2, 10).toUpperCase() + Date.now().toString(36).toUpperCase();
    localStorage.setItem(KILIT_ANAHTARI, kimlik);
  }
  return kimlik;
}

function tahminleriTopla() {
  const tahminler = {};
  for (let i = 1; i <= TOPLAM_MAC; i++) {
    const secili = document.querySelector(`input[name="mac_${i}"]:checked`);
    if (!secili) return { hata: `${i}. maç için tahmin seçmelisin.` };
    tahminler[String(i)] = secili.value;
  }
  return { tahminler };
}

async function apiIstek(adres, veri = null) {
  const ayarlar = veri
    ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(veri) }
    : { method: 'GET' };
  const cevap = await fetch(adres, ayarlar);
  const metin = await cevap.text();
  let json;
  try { json = metin ? JSON.parse(metin) : {}; }
  catch { json = { error: metin || 'Sunucudan okunamayan cevap geldi.' }; }
  if (!cevap.ok) throw new Error(json.error || 'İşlem başarısız oldu.');
  return json;
}

async function kuponKaydet(event) {
  event.preventDefault();
  const eskiKupon = localStorage.getItem(KUPON_ANAHTARI);
  if (eskiKupon) {
    mesajYaz('kuponMesaji', `Bu tarayıcıdan daha önce kupon girilmiş: ${eskiKupon}`, 'hata');
    return;
  }

  const kullaniciAdi = sec('kullaniciAdi').value.trim();
  if (kullaniciAdi.length < 2) {
    mesajYaz('kuponMesaji', 'Adını yazmalısın.', 'hata');
    return;
  }

  const sonuc = tahminleriTopla();
  if (sonuc.hata) {
    mesajYaz('kuponMesaji', sonuc.hata, 'hata');
    return;
  }

  const buton = sec('kuponKilitleBtn');
  buton.disabled = true;
  mesajYaz('kuponMesaji', 'Kupon kaydediliyor...', '');

  try {
    const cevap = await apiIstek('/api/submit-coupon', {
      kullaniciAdi,
      tahminler: sonuc.tahminler,
      tarayiciKilit: tarayiciKimligiAl()
    });
    localStorage.setItem(KUPON_ANAHTARI, cevap.kuponNo);
    mesajYaz('kuponMesaji', `Kuponunuz başarıyla kaydedilmiştir! Kupon numaranız: ${cevap.kuponNo}`, 'ok');
    await liderlikYukle();
  } catch (hata) {
    mesajYaz('kuponMesaji', hata.message, 'hata');
    buton.disabled = false;
  }
}

function liderlikYaz(liste) {
  const alan = sec('liderlikTablosu');
  if (!alan) return;
  if (!Array.isArray(liste) || liste.length === 0) {
    alan.innerHTML = '<p class="bilgi">Maçlar keyfe göre, sonuçlandıkça veya canlıdan güncellenecektir.</p>';
    return;
  }
  alan.innerHTML = liste.map((kisi, index) => `
    <div class="liderlik-satir">
      <strong>#${index + 1}</strong>
      <div>
        <strong>${temizle(kisi.kullanici_adi)}</strong>
        <div class="kucuk">${temizle(kisi.kupon_no)} · Doğru: ${Number(kisi.dogru_sayisi || 0)} · Yanlış: ${Number(kisi.yanlis_sayisi || 0)}</div>
      </div>
      <strong>${Number(kisi.toplam_puan || 0)} Puan</strong>
    </div>
  `).join('');
}

function macDurumlariniYaz(maclar) {
  if (!Array.isArray(maclar)) return;
  for (const mac of maclar) {
    const kart = sec(`mac-${mac.id}`);
    const durum = sec(`durum-${mac.id}`);
    const adminSelect = document.querySelector(`[data-admin-sonuc="${mac.id}"]`);
    if (kart) kart.classList.toggle('bitti', Boolean(mac.tamamlandi));
    if (durum) durum.textContent = mac.tamamlandi ? `Sonuç: ${mac.sonuc}` : 'Beklemede';
    if (adminSelect) adminSelect.value = mac.tamamlandi ? mac.sonuc : '';
  }
}

async function liderlikYukle() {
  try {
    const veri = await apiIstek('/api/state');
    macDurumlariniYaz(veri.maclar);
    liderlikYaz(veri.liderlik);
  } catch {
    liderlikYaz([]);
  }
}

async function kuponSorgula() {
  const kuponNo = sec('kuponAraInput').value.trim().toUpperCase();
  if (!kuponNo) return;
  sec('kuponRaporu').innerHTML = '<p class="bilgi">Sorgulanıyor...</p>';
  try {
    const veri = await apiIstek('/api/query-coupon', { kuponNo });
    const satirlar = veri.detaylar.map((d) => {
      const sinif = d.durum === 'Doğru' ? 'dogru' : d.durum === 'Yanlış' ? 'yanlis' : 'beklemede';
      return `<div class="rapor-satir"><span>${temizle(d.mac)}</span><strong class="${sinif}">${temizle(d.durum)}${d.puan ? ` · ${d.puan} Puan` : ''}</strong></div>`;
    }).join('');
    sec('kuponRaporu').innerHTML = `
      <h3>${temizle(veri.kupon.kupon_no)} · ${temizle(veri.kupon.kullanici_adi)}</h3>
      <p><strong>${Number(veri.kupon.toplam_puan || 0)} Puan</strong> topladı.</p>
      ${satirlar}
    `;
  } catch (hata) {
    sec('kuponRaporu').innerHTML = `<p class="mesaj hata">${temizle(hata.message)}</p>`;
  }
}

async function adminKaydet() {
  const username = sec('adminUser').value.trim();
  const password = sec('adminPassword').value;
  const results = [...document.querySelectorAll('[data-admin-sonuc]')].map((select) => ({
    id: Number(select.dataset.adminSonuc),
    sonuc: select.value || null
  }));

  mesajYaz('adminMesaji', 'Sonuçlar kaydediliyor...', '');
  sec('adminKaydetBtn').disabled = true;

  try {
    const cevap = await apiIstek('/api/admin-score', { username, password, results });
    mesajYaz('adminMesaji', cevap.message || 'Sonuçlar kaydedildi ve puanlar güncellendi.', 'ok');
    await liderlikYukle();
  } catch (hata) {
    mesajYaz('adminMesaji', hata.message, 'hata');
  } finally {
    sec('adminKaydetBtn').disabled = false;
  }
}

function baslat() {
  const eskiKupon = localStorage.getItem(KUPON_ANAHTARI);
  if (eskiKupon) {
    const buton = sec('kuponKilitleBtn');
    if (buton) buton.disabled = true;
    mesajYaz('kuponMesaji', `Bu tarayıcıdan daha önce kupon girilmiş: ${eskiKupon}`, 'hata');
  }
  sec('kuponFormu')?.addEventListener('submit', kuponKaydet);
  sec('kuponAraBtn')?.addEventListener('click', kuponSorgula);
  sec('kuponAraInput')?.addEventListener('keydown', (e) => { if (e.key === 'Enter') kuponSorgula(); });
  sec('adminKaydetBtn')?.addEventListener('click', adminKaydet);
  liderlikYukle();
}

document.addEventListener('DOMContentLoaded', baslat);
