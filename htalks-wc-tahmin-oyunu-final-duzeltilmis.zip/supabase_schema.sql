-- H-Talks Puanlamalı WC Tahmin Oyunu - Supabase Schema
-- Supabase > SQL Editor > New Query içine komple yapıştırıp Run de.
-- Bu dosya tabloları sıfırlar, yeniden kurar ve 24 maçı ekler.

create extension if not exists pgcrypto;

drop table if exists liderlik_tablosu cascade;
drop table if exists kuponlar cascade;
drop table if exists maclar cascade;

create table maclar (
  id integer primary key,
  ev_sahibi text not null,
  deplasman text not null,
  puan_1 integer not null,
  puan_x integer not null,
  puan_2 integer not null,
  sonuc text null check (sonuc in ('1', 'X', '2')),
  tamamlandi boolean not null default false,
  guncellendi timestamptz not null default now()
);

create table kuponlar (
  id uuid primary key default gen_random_uuid(),
  kupon_no text not null unique,
  kullanici_adi text not null,
  tahminler jsonb not null,
  ip_adresi text not null unique,
  tarayici_kilit text not null unique,
  toplam_puan integer not null default 0,
  dogru_sayisi integer not null default 0,
  yanlis_sayisi integer not null default 0,
  olusturuldu timestamptz not null default now(),
  guncellendi timestamptz not null default now()
);

create table liderlik_tablosu (
  id uuid primary key default gen_random_uuid(),
  kupon_id uuid not null references kuponlar(id) on delete cascade,
  kupon_no text not null unique,
  kullanici_adi text not null,
  toplam_puan integer not null default 0,
  dogru_sayisi integer not null default 0,
  yanlis_sayisi integer not null default 0,
  olusturuldu timestamptz not null default now(),
  guncellendi timestamptz not null default now(),
  constraint liderlik_kupon_unique unique (kupon_id)
);

insert into maclar (id, ev_sahibi, deplasman, puan_1, puan_x, puan_2, sonuc, tamamlandi)
values
  (1, 'İsviçre', 'Kanada', 1, 3, 2, null, false),
  (2, 'Bosna Hersek', 'Katar', 1, 5, 7, null, false),
  (3, 'İskoçya', 'Brezilya', 8, 5, 1, null, false),
  (4, 'Fas', 'Haiti', 1, 7, 16, null, false),
  (5, 'Güney Afrika', 'Güney Kore', 5, 3, 1, null, false),
  (6, 'Çekya', 'Meksika', 3, 3, 1, null, false),
  (7, 'Ekvador', 'Almanya', 3, 3, 1, null, false),
  (8, 'Curaçao', 'Fildişi Sahili', 18, 7, 1, null, false),
  (9, 'Japonya', 'İsveç', 1, 3, 4, null, false),
  (10, 'Tunus', 'Hollanda', 21, 8, 1, null, false),
  (11, 'Türkiye', 'ABD', 3, 4, 1, null, false),
  (12, 'Paraguay', 'Avustralya', 2, 2, 3, null, false),
  (13, 'Norveç', 'Fransa', 5, 4, 1, null, false),
  (14, 'Senegal', 'Irak', 1, 6, 12, null, false),
  (15, 'Uruguay', 'İspanya', 6, 4, 1, null, false),
  (16, 'Yeşil Burun', 'Arabistan', 2, 3, 3, null, false),
  (17, 'Yeni Zelanda', 'Belçika', 13, 6, 1, null, false),
  (18, 'Mısır', 'İran', 2, 2, 3, null, false),
  (19, 'Hırvatistan', 'Gana', 1, 3, 5, null, false),
  (20, 'Panama', 'İngiltere', 12, 6, 1, null, false),
  (21, 'Kolombiya', 'Portekiz', 3, 3, 1, null, false),
  (22, 'D. Kongo', 'Özbekistan', 1, 3, 3, null, false),
  (23, 'Cezayir', 'Avusturya', 3, 2, 2, null, false),
  (24, 'Ürdün', 'Arjantin', 12, 6, 1, null, false);

-- Kontrol için:
-- select * from maclar order by id;
