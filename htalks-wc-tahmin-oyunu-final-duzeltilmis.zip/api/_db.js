import { createClient } from '@supabase/supabase-js';

export function supabaseAl() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_SECRET_KEY;
  if (!url || !key) {
    throw new Error('Vercel Environment Variables eksik: SUPABASE_URL ve SUPABASE_SERVICE_ROLE_KEY gerekli.');
  }
  return createClient(url, key, { auth: { persistSession: false } });
}
