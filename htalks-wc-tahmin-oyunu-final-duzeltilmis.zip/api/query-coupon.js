import { supabaseAl } from './_db.js';
import { json, cors, bodyOku } from './_http.js';
import { liderlikGuncelle } from './_logic.js';

export default async function handler(req, res) {
  if (cors(req, res)) return;
  if (req.method !== 'POST') return json(res, 405, { error: 'Sadece POST desteklenir.' });

  try {
    const body = await bodyOku(req);
    const kuponNo = String(body.kuponNo || '').trim().toUpperCase();
    if (!kuponNo) return json(res, 400, { error: 'Kupon numarası yazmalısın.' });

    const supabase = supabaseAl();
    const { data: kupon, error: kuponHata } = await supabase
      .from('kuponlar')
      .select('*')
      .eq('kupon_no', kuponNo)
      .single();
    if (kuponHata || !kupon) return json(res, 404, { error: 'Kupon bulunamadı.' });

    const { data: maclar, error: macHata } = await supabase.from('maclar').select('*').order('id', { ascending: true });
    if (macHata) throw macHata;

    const sonuc = await liderlikGuncelle(supabase, kupon, maclar || []);

    return json(res, 200, {
      kupon: {
        kupon_no: kupon.kupon_no,
        kullanici_adi: kupon.kullanici_adi,
        toplam_puan: sonuc.toplam,
        dogru_sayisi: sonuc.dogru,
        yanlis_sayisi: sonuc.yanlis
      },
      detaylar: sonuc.detaylar
    });
  } catch (hata) {
    return json(res, 500, { error: hata.message || 'Kupon sorgulanamadı.' });
  }
}
