import { supabaseAl } from './_db.js';
import { json, cors, bodyOku } from './_http.js';
import { kuponNoUret, ipAl, tahminleriDogrula, liderlikGuncelle } from './_logic.js';

export default async function handler(req, res) {
  if (cors(req, res)) return;
  if (req.method !== 'POST') return json(res, 405, { error: 'Sadece POST desteklenir.' });

  try {
    const body = await bodyOku(req);
    const kullaniciAdi = String(body.kullaniciAdi || '').trim().slice(0, 40);
    const tahminler = body.tahminler;
    const tarayiciKilit = String(body.tarayiciKilit || '').trim();
    const ipAdresi = ipAl(req);

    if (kullaniciAdi.length < 2) return json(res, 400, { error: 'Adını yazmalısın.' });
    if (tarayiciKilit.length < 6) return json(res, 400, { error: 'Tarayıcı kilidi okunamadı.' });
    tahminleriDogrula(tahminler);

    const supabase = supabaseAl();

    const { data: ipVarMi, error: ipHata } = await supabase
      .from('kuponlar')
      .select('kupon_no')
      .eq('ip_adresi', ipAdresi)
      .limit(1);
    if (ipHata) throw ipHata;
    if (ipVarMi && ipVarMi.length) {
      return json(res, 409, { error: `Bu IP adresinden zaten kupon girilmiş: ${ipVarMi[0].kupon_no}` });
    }

    const { data: tarayiciVarMi, error: tarayiciHata } = await supabase
      .from('kuponlar')
      .select('kupon_no')
      .eq('tarayici_kilit', tarayiciKilit)
      .limit(1);
    if (tarayiciHata) throw tarayiciHata;
    if (tarayiciVarMi && tarayiciVarMi.length) {
      return json(res, 409, { error: `Bu tarayıcıdan zaten kupon girilmiş: ${tarayiciVarMi[0].kupon_no}` });
    }

    let yeniKupon = null;
    for (let deneme = 0; deneme < 8; deneme++) {
      const kuponNo = kuponNoUret();
      const { data, error } = await supabase
        .from('kuponlar')
        .insert({
          kupon_no: kuponNo,
          kullanici_adi: kullaniciAdi,
          tahminler,
          ip_adresi: ipAdresi,
          tarayici_kilit: tarayiciKilit
        })
        .select('*')
        .single();
      if (!error) {
        yeniKupon = data;
        break;
      }
      if (!String(error.message || '').toLowerCase().includes('duplicate')) throw error;
    }

    if (!yeniKupon) return json(res, 500, { error: 'Kupon numarası üretilemedi, tekrar dene.' });

    const { data: maclar, error: macHata } = await supabase.from('maclar').select('*').order('id', { ascending: true });
    if (macHata) throw macHata;
    await liderlikGuncelle(supabase, yeniKupon, maclar || []);

    return json(res, 200, { ok: true, kuponNo: yeniKupon.kupon_no });
  } catch (hata) {
    return json(res, 500, { error: hata.message || 'Kupon kaydedilemedi.' });
  }
}
