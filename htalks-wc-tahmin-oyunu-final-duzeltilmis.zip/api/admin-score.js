import { supabaseAl } from './_db.js';
import { json, cors, bodyOku } from './_http.js';
import { IZINLI, liderlikGuncelle } from './_logic.js';

export default async function handler(req, res) {
  if (cors(req, res)) return;
  if (req.method !== 'POST') return json(res, 405, { error: 'Sadece POST desteklenir.' });

  try {
    const body = await bodyOku(req);
    const adminUser = process.env.ADMIN_USER || 'admin';
    const adminPassword = process.env.ADMIN_PASSWORD || 'aleks02';

    if (body.username !== adminUser || body.password !== adminPassword) {
      return json(res, 401, { error: 'Admin kullanıcı adı veya şifre hatalı.' });
    }

    if (!Array.isArray(body.results)) {
      return json(res, 400, { error: 'Sonuç listesi geçersiz.' });
    }

    const supabase = supabaseAl();
    const simdi = new Date().toISOString();
    const temizSonuclar = body.results.map((item) => {
      const id = Number(item.id);
      const sonuc = item.sonuc || null;
      if (!Number.isInteger(id) || id < 1 || id > 24) throw new Error('Geçersiz maç numarası.');
      if (sonuc !== null && !IZINLI.has(sonuc)) throw new Error('Geçersiz sonuç değeri.');
      return { id, sonuc, tamamlandi: Boolean(sonuc), guncellendi: simdi };
    });

    const { error: upsertHata } = await supabase
      .from('maclar')
      .upsert(temizSonuclar, { onConflict: 'id' });
    if (upsertHata) throw upsertHata;

    const { data: maclar, error: macHata } = await supabase.from('maclar').select('*').order('id', { ascending: true });
    if (macHata) throw macHata;

    const { data: kuponlar, error: kuponHata } = await supabase.from('kuponlar').select('*');
    if (kuponHata) throw kuponHata;

    for (const kupon of kuponlar || []) {
      await liderlikGuncelle(supabase, kupon, maclar || []);
    }

    return json(res, 200, { ok: true, message: 'Sonuçlar kaydedildi ve tüm puanlar güncellendi.' });
  } catch (hata) {
    return json(res, 500, { error: hata.message || 'Admin güncellemesi yapılamadı.' });
  }
}
