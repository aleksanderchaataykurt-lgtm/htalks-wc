import { supabaseAl } from './_db.js';
import { json, cors } from './_http.js';
import { MACLAR } from './_matches.js';

export default async function handler(req, res) {
  if (cors(req, res)) return;
  if (req.method !== 'GET') return json(res, 405, { error: 'Sadece GET desteklenir.' });

  try {
    const supabase = supabaseAl();
    const { data: maclar, error: macHata } = await supabase.from('maclar').select('*').order('id', { ascending: true });
    if (macHata) throw macHata;

    const { data: liderlik, error: liderHata } = await supabase
      .from('liderlik_tablosu')
      .select('*')
      .order('toplam_puan', { ascending: false })
      .order('dogru_sayisi', { ascending: false })
      .order('olusturuldu', { ascending: true })
      .limit(200);
    if (liderHata) throw liderHata;

    return json(res, 200, { maclar: maclar?.length ? maclar : MACLAR, liderlik: liderlik || [] });
  } catch (hata) {
    return json(res, 200, { maclar: MACLAR, liderlik: [], warning: hata.message });
  }
}
