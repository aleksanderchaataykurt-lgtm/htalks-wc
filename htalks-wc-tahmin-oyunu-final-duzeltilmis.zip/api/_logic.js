import { MACLAR } from './_matches.js';

export const IZINLI = new Set(['1', 'X', '2']);

export function ipAl(req) {
  const aday = req.headers['x-forwarded-for'] || req.headers['x-real-ip'] || req.socket?.remoteAddress || '';
  return String(aday).split(',')[0].trim() || 'bilinmeyen-ip';
}

export function kuponNoUret() {
  const parca = Math.floor(1000 + Math.random() * 9000);
  const harf = Math.random().toString(36).slice(2, 4).toUpperCase();
  return `HT-${parca}${harf}`;
}

export function tahminleriDogrula(tahminler) {
  if (!tahminler || typeof tahminler !== 'object' || Array.isArray(tahminler)) {
    throw new Error('Tahminler geçersiz.');
  }
  for (const mac of MACLAR) {
    const secim = tahminler[String(mac.id)];
    if (!IZINLI.has(secim)) throw new Error(`${mac.id}. maç için tahmin eksik veya geçersiz.`);
  }
  return true;
}

export function puanAl(mac, secim) {
  if (secim === '1') return Number(mac.puan_1 || 0);
  if (secim === 'X') return Number(mac.puan_x || 0);
  if (secim === '2') return Number(mac.puan_2 || 0);
  return 0;
}

export function hesapla(kupon, maclar) {
  const macHaritasi = new Map((maclar || []).map((m) => [Number(m.id), m]));
  const tahminler = kupon.tahminler || {};
  let toplam = 0;
  let dogru = 0;
  let yanlis = 0;
  const detaylar = [];

  for (const sabit of MACLAR) {
    const mac = macHaritasi.get(Number(sabit.id)) || sabit;
    const secim = tahminler[String(sabit.id)];
    const tamamlandi = Boolean(mac.tamamlandi || mac.sonuc);
    let durum = 'Beklemede';
    let puan = 0;

    if (tamamlandi) {
      if (secim === mac.sonuc) {
        durum = 'Doğru';
        puan = puanAl(mac, secim);
        toplam += puan;
        dogru += 1;
      } else {
        durum = 'Yanlış';
        yanlis += 1;
      }
    }

    detaylar.push({
      id: sabit.id,
      mac: `${sabit.ev_sahibi} - ${sabit.deplasman}`,
      tahmin: secim,
      sonuc: tamamlandi ? mac.sonuc : null,
      durum,
      puan
    });
  }

  return { toplam, dogru, yanlis, detaylar };
}

export async function liderlikGuncelle(supabase, kupon, maclar) {
  const sonuc = hesapla(kupon, maclar);

  await supabase
    .from('kuponlar')
    .update({
      toplam_puan: sonuc.toplam,
      dogru_sayisi: sonuc.dogru,
      yanlis_sayisi: sonuc.yanlis,
      guncellendi: new Date().toISOString()
    })
    .eq('id', kupon.id);

  await supabase
    .from('liderlik_tablosu')
    .upsert({
      kupon_id: kupon.id,
      kupon_no: kupon.kupon_no,
      kullanici_adi: kupon.kullanici_adi,
      toplam_puan: sonuc.toplam,
      dogru_sayisi: sonuc.dogru,
      yanlis_sayisi: sonuc.yanlis,
      guncellendi: new Date().toISOString()
    }, { onConflict: 'kupon_id' });

  return sonuc;
}
