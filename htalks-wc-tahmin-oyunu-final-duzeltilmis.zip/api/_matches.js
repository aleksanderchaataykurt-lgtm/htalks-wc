export const MACLAR = [
  {
    "id": 1,
    "ev_sahibi": "İsviçre",
    "deplasman": "Kanada",
    "puan_1": 1,
    "puan_x": 3,
    "puan_2": 2,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 2,
    "ev_sahibi": "Bosna Hersek",
    "deplasman": "Katar",
    "puan_1": 1,
    "puan_x": 5,
    "puan_2": 7,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 3,
    "ev_sahibi": "İskoçya",
    "deplasman": "Brezilya",
    "puan_1": 8,
    "puan_x": 5,
    "puan_2": 1,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 4,
    "ev_sahibi": "Fas",
    "deplasman": "Haiti",
    "puan_1": 1,
    "puan_x": 7,
    "puan_2": 16,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 5,
    "ev_sahibi": "Güney Afrika",
    "deplasman": "Güney Kore",
    "puan_1": 5,
    "puan_x": 3,
    "puan_2": 1,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 6,
    "ev_sahibi": "Çekya",
    "deplasman": "Meksika",
    "puan_1": 3,
    "puan_x": 3,
    "puan_2": 1,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 7,
    "ev_sahibi": "Ekvador",
    "deplasman": "Almanya",
    "puan_1": 3,
    "puan_x": 3,
    "puan_2": 1,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 8,
    "ev_sahibi": "Curaçao",
    "deplasman": "Fildişi Sahili",
    "puan_1": 18,
    "puan_x": 7,
    "puan_2": 1,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 9,
    "ev_sahibi": "Japonya",
    "deplasman": "İsveç",
    "puan_1": 1,
    "puan_x": 3,
    "puan_2": 4,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 10,
    "ev_sahibi": "Tunus",
    "deplasman": "Hollanda",
    "puan_1": 21,
    "puan_x": 8,
    "puan_2": 1,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 11,
    "ev_sahibi": "Türkiye",
    "deplasman": "ABD",
    "puan_1": 3,
    "puan_x": 4,
    "puan_2": 1,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 12,
    "ev_sahibi": "Paraguay",
    "deplasman": "Avustralya",
    "puan_1": 2,
    "puan_x": 2,
    "puan_2": 3,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 13,
    "ev_sahibi": "Norveç",
    "deplasman": "Fransa",
    "puan_1": 5,
    "puan_x": 4,
    "puan_2": 1,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 14,
    "ev_sahibi": "Senegal",
    "deplasman": "Irak",
    "puan_1": 1,
    "puan_x": 6,
    "puan_2": 12,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 15,
    "ev_sahibi": "Uruguay",
    "deplasman": "İspanya",
    "puan_1": 6,
    "puan_x": 4,
    "puan_2": 1,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 16,
    "ev_sahibi": "Yeşil Burun",
    "deplasman": "Arabistan",
    "puan_1": 2,
    "puan_x": 3,
    "puan_2": 3,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 17,
    "ev_sahibi": "Yeni Zelanda",
    "deplasman": "Belçika",
    "puan_1": 13,
    "puan_x": 6,
    "puan_2": 1,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 18,
    "ev_sahibi": "Mısır",
    "deplasman": "İran",
    "puan_1": 2,
    "puan_x": 2,
    "puan_2": 3,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 19,
    "ev_sahibi": "Hırvatistan",
    "deplasman": "Gana",
    "puan_1": 1,
    "puan_x": 3,
    "puan_2": 5,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 20,
    "ev_sahibi": "Panama",
    "deplasman": "İngiltere",
    "puan_1": 12,
    "puan_x": 6,
    "puan_2": 1,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 21,
    "ev_sahibi": "Kolombiya",
    "deplasman": "Portekiz",
    "puan_1": 3,
    "puan_x": 3,
    "puan_2": 1,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 22,
    "ev_sahibi": "D. Kongo",
    "deplasman": "Özbekistan",
    "puan_1": 1,
    "puan_x": 3,
    "puan_2": 3,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 23,
    "ev_sahibi": "Cezayir",
    "deplasman": "Avusturya",
    "puan_1": 3,
    "puan_x": 2,
    "puan_2": 2,
    "sonuc": null,
    "tamamlandi": false
  },
  {
    "id": 24,
    "ev_sahibi": "Ürdün",
    "deplasman": "Arjantin",
    "puan_1": 12,
    "puan_x": 6,
    "puan_2": 1,
    "sonuc": null,
    "tamamlandi": false
  }
];
